﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class ViewCc
    {
        public string FacilityNo { get; set; }
        public string CustCode { get; set; }
        public string CcsNo { get; set; }
    }
}
