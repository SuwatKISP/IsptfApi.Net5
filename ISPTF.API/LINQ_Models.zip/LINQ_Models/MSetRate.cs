﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class MSetRate
    {
        public string Module { get; set; }
        public string Rateid { get; set; }
        public double? Rate { get; set; }
    }
}
