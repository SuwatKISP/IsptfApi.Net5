﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class PImlccond
    {
        public string CenterId { get; set; }
        public string Lcnumber { get; set; }
        public string RecType { get; set; }
        public int Lcseqno { get; set; }
        public string Mt { get; set; }
        public string AddCondition { get; set; }
    }
}
