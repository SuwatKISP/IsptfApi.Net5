﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class Mlogin
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
