﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class ViewMapAccount
    {
        public string AccCode { get; set; }
        public string AccName { get; set; }
        public string MAccNew { get; set; }
        public string MAccType { get; set; }
        public string MAccBuArea { get; set; }
        public string MAccCost { get; set; }
        public string MAccProfit { get; set; }
        public string MAccBsLine { get; set; }
        public string MAccCond { get; set; }
        public string MAccMod { get; set; }
    }
}
