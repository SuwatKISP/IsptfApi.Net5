﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class VCustSumFac
    {
        public string CustCode { get; set; }
        public string FacilityType { get; set; }
        public double? LaibFacAmt { get; set; }
    }
}
