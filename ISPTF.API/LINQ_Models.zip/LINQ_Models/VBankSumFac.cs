﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class VBankSumFac
    {
        public string BankCode { get; set; }
        public string FacilityType { get; set; }
        public double? LaibFacAmt { get; set; }
    }
}
