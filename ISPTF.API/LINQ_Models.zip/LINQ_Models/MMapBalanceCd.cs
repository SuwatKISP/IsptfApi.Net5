﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class MMapBalanceCd
    {
        public string Login { get; set; }
        public string RefNo { get; set; }
        public string Rtype { get; set; }
        public string Rstatus { get; set; }
        public string ProdCcy { get; set; }
        public string ProdThb { get; set; }
        public string Gfmsacc { get; set; }
        public string Gfmssub { get; set; }
        public string Gfmsmap { get; set; }
        public string OutsBlcode { get; set; }
        public string IntsBlcode { get; set; }
        public string CreateDate { get; set; }
    }
}
