﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class MDsperror
    {
        public string ErrCode { get; set; }
        public string ErrDesc { get; set; }
    }
}
