﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class ViewNostro
    {
        public string NostroBank { get; set; }
        public string NostroCcy { get; set; }
        public string BankName { get; set; }
        public string RecStatus { get; set; }
        public string BankCnty { get; set; }
    }
}
