﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class ViewOsbyCcs1
    {
        public string Custcode { get; set; }
        public string Flagdue { get; set; }
        public string Facno { get; set; }
        public string CcsAcct { get; set; }
        public string CcsLmtype { get; set; }
        public string Module { get; set; }
        public double? OutstdAmtThb { get; set; }
    }
}
