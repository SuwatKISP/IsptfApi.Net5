﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class PSwprint
    {
        public string SwfileName { get; set; }
        public string Swuser { get; set; }
        public int SwSeq { get; set; }
        public string SwDesc { get; set; }
    }
}
