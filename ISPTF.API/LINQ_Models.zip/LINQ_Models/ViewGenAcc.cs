﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class ViewGenAcc
    {
        public string AccMap { get; set; }
        public string Amodule { get; set; }
        public string Aevent { get; set; }
        public int Aseq { get; set; }
        public string Accode { get; set; }
        public string Anature { get; set; }
        public string Accy { get; set; }
        public string Aname { get; set; }
    }
}
