﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class PSw707
    {
        public string Lcno { get; set; }
        public int Seqno { get; set; }
        public string M20 { get; set; }
        public string M21 { get; set; }
        public string F31c { get; set; }
        public string F30 { get; set; }
        public string M30 { get; set; }
        public string F26e { get; set; }
        public string M59 { get; set; }
        public string F31e { get; set; }
        public string M32b { get; set; }
        public string F32b { get; set; }
        public string F33b { get; set; }
        public string F34b { get; set; }
        public string F39a { get; set; }
        public string F44a { get; set; }
        public string F44b { get; set; }
        public string F44c { get; set; }
        public string F44d { get; set; }
        public string F72 { get; set; }
        public string F77a { get; set; }
        public string F79 { get; set; }
        public string F72747 { get; set; }
        public string Flag747 { get; set; }
        public string Flag740 { get; set; }
        public string M31d { get; set; }
        public string M41a { get; set; }
        public string F42c { get; set; }
        public string F42a { get; set; }
        public string F42m740 { get; set; }
        public string F42p { get; set; }
        public string F71a740 { get; set; }
        public string F71b740 { get; set; }
        public string F72740 { get; set; }
    }
}
