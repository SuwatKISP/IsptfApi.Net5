﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class Ibbftx1801052
    {
        public string Column0 { get; set; }
        public string Column1 { get; set; }
        public string Column2 { get; set; }
        public string Column3 { get; set; }
        public string Column4 { get; set; }
        public string Column5 { get; set; }
        public string Column6 { get; set; }
        public string Column7 { get; set; }
        public string Column8 { get; set; }
        public string Column9 { get; set; }
        public string Column10 { get; set; }
        public string Column11 { get; set; }
        public string Column12 { get; set; }
        public string Column13 { get; set; }
        public string Column14 { get; set; }
        public string Column15 { get; set; }
        public string Column16 { get; set; }
        public string Column17 { get; set; }
        public string Column18 { get; set; }
        public string Column19 { get; set; }
        public string Column20 { get; set; }
        public string Column21 { get; set; }
        public string Column22 { get; set; }
        public string Column23 { get; set; }
        public string Column24 { get; set; }
        public string Column25 { get; set; }
        public string Column26 { get; set; }
        public string Column27 { get; set; }
        public string Column28 { get; set; }
        public string Column29 { get; set; }
        public string Column30 { get; set; }
        public string Column31 { get; set; }
        public string Column32 { get; set; }
        public string Column33 { get; set; }
        public string Column34 { get; set; }
        public string Column35 { get; set; }
        public string Column36 { get; set; }
        public string Column37 { get; set; }
        public string Column38 { get; set; }
        public string Column39 { get; set; }
        public string Column40 { get; set; }
        public string Column41 { get; set; }
        public string Column42 { get; set; }
        public string Column43 { get; set; }
        public string Column44 { get; set; }
        public string Column45 { get; set; }
        public string Column46 { get; set; }
        public string Column47 { get; set; }
        public string Column48 { get; set; }
        public string Column49 { get; set; }
        public string Column50 { get; set; }
        public string Column51 { get; set; }
        public string Column52 { get; set; }
        public string Column53 { get; set; }
        public string Column54 { get; set; }
        public string Column55 { get; set; }
        public string Column56 { get; set; }
        public string Column57 { get; set; }
        public string Column58 { get; set; }
        public string Column59 { get; set; }
        public string Column60 { get; set; }
        public string Column61 { get; set; }
        public string Column62 { get; set; }
        public string Column63 { get; set; }
        public string Column64 { get; set; }
        public string Column65 { get; set; }
        public string Column66 { get; set; }
        public string Column67 { get; set; }
        public string Column68 { get; set; }
        public string Column69 { get; set; }
        public string Column70 { get; set; }
    }
}
