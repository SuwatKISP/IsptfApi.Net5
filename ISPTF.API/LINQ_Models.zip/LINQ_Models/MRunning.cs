﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class MRunning
    {
        public string CustShow { get; set; }
        public decimal? CustRun { get; set; }
    }
}
