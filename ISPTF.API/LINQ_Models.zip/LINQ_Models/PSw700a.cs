﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class PSw700a
    {
        public string Lcno { get; set; }
        public int SeqNo { get; set; }
        public string F45a { get; set; }
    }
}
