﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class TmpOnlLcswfile
    {
        public string LneName { get; set; }
        public int? LneNo { get; set; }
        public string LneData { get; set; }
        public string LneFile { get; set; }
    }
}
