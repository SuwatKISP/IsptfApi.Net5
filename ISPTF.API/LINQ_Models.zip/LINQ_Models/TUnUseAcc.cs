﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class TUnUseAcc
    {
        public string PRefTrans { get; set; }
        public string PRefYear { get; set; }
        public string Acctno { get; set; }
        public bool? InUse { get; set; }
    }
}
