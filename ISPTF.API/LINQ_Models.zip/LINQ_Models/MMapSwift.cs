﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class MMapSwift
    {
        public string Mttype { get; set; }
        public string Fdnumber { get; set; }
        public string Fdname { get; set; }
    }
}
