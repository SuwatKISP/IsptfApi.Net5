﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class PLogSwiftInHead
    {
        public string SwiftInId { get; set; }
        public string SwiftInType { get; set; }
        public string Head1 { get; set; }
        public string Head2 { get; set; }
        public string Head3 { get; set; }
        public string FromBank { get; set; }
    }
}
