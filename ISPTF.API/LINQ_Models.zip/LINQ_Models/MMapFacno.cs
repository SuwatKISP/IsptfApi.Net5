﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class MMapFacno
    {
        public string CustCode { get; set; }
        public string FacNo { get; set; }
        public string IsicCode { get; set; }
        public string PurposeCode { get; set; }
    }
}
