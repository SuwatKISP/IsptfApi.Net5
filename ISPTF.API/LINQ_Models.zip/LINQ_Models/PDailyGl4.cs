﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class PDailyGl4
    {
        public string VouchDate { get; set; }
        public string VouchId { get; set; }
        public string TranSeq { get; set; }
        public string TranDocNo { get; set; }
        public string TranDocseq { get; set; }
        public string TranAccount { get; set; }
        public string TranCcy { get; set; }
        public string TranNature { get; set; }
        public string TranExch { get; set; }
        public string TranAmount { get; set; }
        public string TranDesc { get; set; }
        public string TranRef { get; set; }
        public string TranMod { get; set; }
        public string TranEvent { get; set; }
        public string TranBran { get; set; }
        public string TranDept { get; set; }
        public string TranCenter { get; set; }
        public string TranStatus { get; set; }
        public string TranAllocate { get; set; }
        public string CustCode { get; set; }
        public string CreateDate { get; set; }
        public string SendFlag { get; set; }
        public string TranCond { get; set; }
    }
}
