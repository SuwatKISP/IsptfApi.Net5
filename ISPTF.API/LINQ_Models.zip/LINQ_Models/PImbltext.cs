﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class PImbltext
    {
        public string Adnumber { get; set; }
        public int Seqno { get; set; }
        public string Text23 { get; set; }
        public string Text79 { get; set; }
        public string Text72 { get; set; }
        public string Text791 { get; set; }
        public string Text792 { get; set; }
        public string Text77 { get; set; }
        public string CenterId { get; set; }
    }
}
