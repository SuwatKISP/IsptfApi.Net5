﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class MAuth
    {
        public string UserId { get; set; }
        public string ModCode { get; set; }
        public string ModLevel { get; set; }
    }
}
