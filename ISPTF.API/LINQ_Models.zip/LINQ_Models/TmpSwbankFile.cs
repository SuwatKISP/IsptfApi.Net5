﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class TmpSwbankFile
    {
        public string BankCode { get; set; }
        public string BankSwift { get; set; }
        public string BankAdd1 { get; set; }
        public string BankAdd2 { get; set; }
        public string BankAdd3 { get; set; }
        public string BankAdd4 { get; set; }
    }
}
