﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class POnlunMatchCust
    {
        public string AccessId { get; set; }
        public string TradeRefNumber { get; set; }
        public string EditionNumber { get; set; }
        public string Cif { get; set; }
        public string Status { get; set; }
    }
}
