﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class MSetGenGl
    {
        public string Amodule { get; set; }
        public string Aevent { get; set; }
        public string Aseq { get; set; }
        public string Accode { get; set; }
        public string Anature { get; set; }
        public string Accy { get; set; }
        public string Aname { get; set; }
        public string Aflag { get; set; }
        public string Acond { get; set; }
        public string Anote { get; set; }
        public string Acenter { get; set; }
    }
}
