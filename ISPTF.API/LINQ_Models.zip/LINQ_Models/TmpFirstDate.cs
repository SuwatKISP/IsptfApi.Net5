﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class TmpFirstDate
    {
        public string CustCode { get; set; }
        public string FacNo { get; set; }
        public DateTime? EventDate { get; set; }
    }
}
