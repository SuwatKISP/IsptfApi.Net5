﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class VtempCc
    {
        public string CustCode { get; set; }
        public string CustCif { get; set; }
        public string CustName { get; set; }
        public string CcsNo { get; set; }
        public string FacilityNo { get; set; }
    }
}
