﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class PTradeApp
    {
        public int CompanyId { get; set; }
        public string TradeRefNumber { get; set; }
        public string EditionNumber { get; set; }
        public string LcNumber { get; set; }
    }
}
