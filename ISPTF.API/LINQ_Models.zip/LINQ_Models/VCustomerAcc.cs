﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class VCustomerAcc
    {
        public string CustCode { get; set; }
        public string CustAcNo { get; set; }
        public string CustAcName { get; set; }
        public string CustAcType { get; set; }
    }
}
