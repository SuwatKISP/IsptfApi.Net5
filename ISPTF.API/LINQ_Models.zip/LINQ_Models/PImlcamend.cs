﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class PImlcamend
    {
        public string CenterId { get; set; }
        public string Lcnumber { get; set; }
        public string RecType { get; set; }
        public int Lcseqno { get; set; }
        public string Narr77A { get; set; }
        public string Amend79 { get; set; }
    }
}
