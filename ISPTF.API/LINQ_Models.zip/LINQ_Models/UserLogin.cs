﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class UserLogin
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
