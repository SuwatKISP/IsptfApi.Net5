﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class ConvExbc
    {
        public string Exportlcno { get; set; }
        public double? DiscAmorTo { get; set; }
    }
}
