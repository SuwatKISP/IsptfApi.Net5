﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class MBuArea
    {
        public string BaCode { get; set; }
        public string BaDesc { get; set; }
        public string BaCost { get; set; }
        public string BaProfit { get; set; }
    }
}
