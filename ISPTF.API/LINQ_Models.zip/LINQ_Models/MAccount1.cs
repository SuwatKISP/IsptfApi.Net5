﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class MAccount1
    {
        public string AccCode { get; set; }
        public string AccName { get; set; }
        public string AccMap { get; set; }
        public string CreateDate { get; set; }
        public string UpdateDate { get; set; }
        public string UserCode { get; set; }
        public string AccGfms { get; set; }
        public string AccGfmsSub { get; set; }
        public string GfmsMap { get; set; }
        public string GfmsProd { get; set; }
        public string GfmsBran { get; set; }
        public string GfmsSbu { get; set; }
    }
}
