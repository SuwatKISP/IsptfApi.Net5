﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class ViewFcpimport
    {
        public string Ccy { get; set; }
        public double? SumAmt { get; set; }
    }
}
