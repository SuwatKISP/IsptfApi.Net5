﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class PImbldoc
    {
        public string CenterId { get; set; }
        public string Adnumber { get; set; }
        public int SeqNo { get; set; }
        public string DocDetails { get; set; }
        public string OrgCopy { get; set; }
        public string Copy { get; set; }
    }
}
