﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class VImfwcont
    {
        public string DocNumber { get; set; }
        public int DocSeqno { get; set; }
        public string DocCcy { get; set; }
        public string CustCode { get; set; }
    }
}
