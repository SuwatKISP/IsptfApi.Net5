﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class TmpSwiftin
    {
        public string Fduser { get; set; }
        public string Fdfile { get; set; }
        public string Fdmt { get; set; }
        public int? Fdline { get; set; }
        public string Fddetail { get; set; }
    }
}
