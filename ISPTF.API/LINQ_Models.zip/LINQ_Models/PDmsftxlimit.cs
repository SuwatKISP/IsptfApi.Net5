﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class PDmsftxlimit
    {
        public string DeleteFlag { get; set; }
        public string EventNo { get; set; }
        public double? FtxAmount { get; set; }
    }
}
