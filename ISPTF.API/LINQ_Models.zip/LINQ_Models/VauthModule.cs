﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class VauthModule
    {
        public string UserId { get; set; }
        public string ModCode { get; set; }
        public string CtlType { get; set; }
        public string CtlName { get; set; }
        public string CtlDesc { get; set; }
        public string CtlNote1 { get; set; }
    }
}
