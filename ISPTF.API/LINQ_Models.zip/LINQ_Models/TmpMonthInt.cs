﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class TmpMonthInt
    {
        public string DocMonth { get; set; }
        public string CenterId { get; set; }
        public string DocCust { get; set; }
        public string NumToWord { get; set; }
    }
}
