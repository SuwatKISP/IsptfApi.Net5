﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ISPTF.Models.LINQ
{
    public partial class PImtrtext
    {
        public string Trnumber { get; set; }
        public string RefNumber { get; set; }
        public int Seqno { get; set; }
        public string Text79 { get; set; }
        public string Text791 { get; set; }
    }
}
